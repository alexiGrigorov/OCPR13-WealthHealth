export const DEPARTMENTS = [
  { code: "SALES", name: "Sales" },
  { code: "MARKETING", name: "Marketing" },
  { code: "ENGINEERING", name: "Engineering" },
  { code: "HUMAN_RESOURCES", name: "Human Resources" },
  { code: "LEGAL", name: "Legal" },
];
